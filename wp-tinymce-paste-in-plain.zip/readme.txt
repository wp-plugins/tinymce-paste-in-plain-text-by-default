=== TinyMCE Paste in Plain Text by Default ===
Contributors: raphaabreu
Donate link: 
Tags: tinymce, paste, plain text
Requires at least: 3.3
Tested up to: 3.5.1
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Changes the default behavior on TinyMCE so that all text is pasted plain by default.


== Description ==

After activating this plugin TinyMCE will start to paste plain text by default. 
This is helpful if users are not familiar with HTML and styling and how that can get 
terribly messed up when you paste formatted text from Microsoft Word or other rich 
text software.


== Installation ==

1. Upload `wp-tinymce-paste-in-plain.php` to the `/wp-content/plugins/` directory.
1. Activate the plugin through the 'Plugins' menu in WordPress.
That's it!


== Changelog ==

= 1.0 =
* Initial revision.